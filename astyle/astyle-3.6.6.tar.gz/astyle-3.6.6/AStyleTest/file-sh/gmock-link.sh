# link gtest to version directory

gtdir=gmock-1.7.0

#link to version directory
cd ../../
sudo  ln  --force --symbolic --verbose  $HOME/Projects/$gtdir   $HOME/Projects/gmock
